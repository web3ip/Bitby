const connectWalletBtn = document.getElementById("connectWallet");
const walletAddress = document.getElementById("walletAddress");
const priceList = document.getElementById("priceList");

connectWalletBtn.addEventListener("click", async () => {
  if (window.ethereum) {
    try {
      const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
      const address = accounts[0];
      walletAddress.textContent = "Wallet: " + address;
    } catch (error) {
      console.error("User rejected wallet connection", error);
    }
  } else {
    alert("Please install MetaMask to connect your wallet.");
  }
});

async function fetchPrices() {
  const response = await fetch("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,usd-coin&vs_currencies=usd");
  const data = await response.json();
  
  priceList.innerHTML = `
    <div class="price-item">Bitcoin (BTC): $${data.bitcoin.usd}</div>
    <div class="price-item">Ethereum (ETH): $${data.ethereum.usd}</div>
    <div class="price-item">USDC (USD Coin): $${data['usd-coin'].usd}</div>
  `;
}

fetchPrices();
setInterval(fetchPrices, 30000); // Refresh every 30s